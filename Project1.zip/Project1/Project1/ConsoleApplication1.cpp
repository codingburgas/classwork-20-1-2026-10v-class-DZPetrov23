#include "../ConsoleApplication1/MathLibrary.h"

int main()
{
    Function(3, 6, 7);
}


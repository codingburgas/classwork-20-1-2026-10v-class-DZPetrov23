#include "MathLibrary.h"


void Function(int a, int b, int c) {
	cout << "perimeter is:" << a + b + c;
	cout << "\nplot is: " << c;
}